# SA-MP-MySQL-R5
Old version (R5) of MySQL plugin by BlueG for San Andreas Multiplayer.

This is old version, it's no longer supported. This is full copy of R5 source uploaded because original links are now dead and people have problems finding old version to work with their gamemodes.
