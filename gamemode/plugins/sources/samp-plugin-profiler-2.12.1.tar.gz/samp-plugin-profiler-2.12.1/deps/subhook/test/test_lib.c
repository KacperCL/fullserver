#include <stdio.h>

void foo() {
	printf("foo() called\n");
}

void foo_hook() {
	printf("foo_hook() called\n");
}
